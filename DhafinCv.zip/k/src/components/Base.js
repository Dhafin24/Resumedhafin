import {memo} from 'react';

const Base = memo(() => {
  return <></>;
});

Base.displayName = 'Base';
export default Base;
